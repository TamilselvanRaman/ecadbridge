eCAD BRIDGE - BRAND FONTS
=========================

All three fonts are free under the SIL Open Font License (OFL.txt in each folder).
You may install, use commercially, embed in documents and share them.

WHICH FONT IS USED WHERE
------------------------
Fredoka SemiBold   ->  "CAD" and "ridge" in the logo
Fredoka Bold       ->  bold headings in the same rounded style
Fredoka Regular / Medium -> body text and sub-headings
Montserrat Bold    ->  website line (eCADBridge.com)
Montserrat Medium  ->  tagline "Your Engineering Integration System"
IBM Plex Mono Medium -> spaced-out tagline (YOUR ENGINEERING INTEGRATION SYSTEM)

IMPORTANT: the circuit "e" and "b" in the logo are artwork, not letters in a font.
Always place the logo from the SVG / PDF logo files; do not retype it.

HOW TO INSTALL
--------------
Windows: select all .ttf files > right-click > "Install for all users".
         Restart Word, Photoshop and CorelDRAW afterwards.
macOS:   double-click each .ttf > "Install Font" (or drag into Font Book).

IN EACH APP
-----------
Word:       the fonts appear as "Fredoka", "Fredoka Medium", "Fredoka SemiBold",
            "Montserrat", "Montserrat Medium", "IBM Plex Mono".
            To share .docx files with people who don't have the fonts:
            File > Options > Save > tick "Embed fonts in the file".
Photoshop:  pick the family, then the style (e.g. Fredoka > SemiBold).
CorelDRAW:  same as Photoshop. Before sending files to a printer,
            select the text and press Ctrl+Q (Convert to Curves).

BRAND COLOURS
-------------
Navy background   #0E1621
White "CAD"       #F2F4F7
Cyan "ridge"      #29B6F6
Gold traces       #D4A84B
Tagline grey      #8FA3B8
T-shirt (merch):  Royal blue #1F5FD6 + Signal red #E0362C,
                  Deep teal #0B7A75 + Coral #F2603A, Full black #141414
